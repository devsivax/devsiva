(function () {
  "use strict";

  var prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------------- Theme toggle ---------------- */
  var root = document.documentElement;
  var themeToggleBtns = document.querySelectorAll("[data-theme-toggle]");

  function getStoredTheme() {
    try { return localStorage.getItem("portfolio-theme"); } catch (e) { return null; }
  }
  function storeTheme(value) {
    try { localStorage.setItem("portfolio-theme", value); } catch (e) { /* ignore */ }
  }
  function applyTheme(theme) {
    root.setAttribute("data-theme", theme);
    themeToggleBtns.forEach(function (btn) {
      btn.querySelector("[data-theme-label]").textContent = theme === "dark" ? "light mode" : "dark mode";
    });
  }
  var stored = getStoredTheme();
  if (stored) {
    applyTheme(stored);
  } else {
    var systemDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    applyTheme(systemDark ? "dark" : "light");
  }
  themeToggleBtns.forEach(function (btn) {
    btn.addEventListener("click", function () {
      var current = root.getAttribute("data-theme") === "dark" ? "dark" : "light";
      var next = current === "dark" ? "light" : "dark";
      applyTheme(next);
      storeTheme(next);
    });
  });

  /* ---------------- Mobile nav ---------------- */
  var hamburger = document.querySelector(".hamburger");
  var sidebar = document.querySelector(".sidebar");
  var overlay = document.querySelector(".overlay");

  function closeMenu() {
    sidebar.classList.remove("open");
    overlay.classList.remove("show");
    hamburger.setAttribute("aria-expanded", "false");
  }
  function openMenu() {
    sidebar.classList.add("open");
    overlay.classList.add("show");
    hamburger.setAttribute("aria-expanded", "true");
  }
  if (hamburger) {
    hamburger.addEventListener("click", function () {
      var isOpen = sidebar.classList.contains("open");
      isOpen ? closeMenu() : openMenu();
    });
  }
  if (overlay) overlay.addEventListener("click", closeMenu);
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeMenu();
  });
  document.querySelectorAll(".file-tree a").forEach(function (link) {
    link.addEventListener("click", closeMenu);
  });

  /* ---------------- Active nav highlighting ---------------- */
  var sections = document.querySelectorAll("main section[id]");
  var navLinks = document.querySelectorAll(".file-tree a[href^='#']");

  function setActiveLink(id) {
    navLinks.forEach(function (link) {
      var match = link.getAttribute("href") === "#" + id;
      link.classList.toggle("active", match);
      if (match) link.setAttribute("aria-current", "true");
      else link.removeAttribute("aria-current");
    });
  }

  if ("IntersectionObserver" in window && sections.length) {
    var navObserver = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) setActiveLink(entry.target.id);
        });
      },
      { rootMargin: "-40% 0px -50% 0px", threshold: 0 }
    );
    sections.forEach(function (s) { navObserver.observe(s); });
  }

  /* ---------------- Scroll reveal for project cards ---------------- */
  var revealEls = document.querySelectorAll(".project-card");
  if (prefersReducedMotion || !("IntersectionObserver" in window)) {
    revealEls.forEach(function (el) { el.classList.add("in-view"); });
  } else {
    var revealObserver = new IntersectionObserver(
      function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    revealEls.forEach(function (el) { revealObserver.observe(el); });
  }

  /* ---------------- Back to top ---------------- */
  var backToTop = document.querySelector(".back-to-top");
  if (backToTop) {
    window.addEventListener("scroll", function () {
      backToTop.classList.toggle("show", window.scrollY > 500);
    });
    backToTop.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: prefersReducedMotion ? "auto" : "smooth" });
    });
  }

  /* ---------------- Copy email ---------------- */
  document.querySelectorAll("[data-copy]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var text = btn.getAttribute("data-copy");
      var done = function () {
        var original = btn.textContent;
        btn.textContent = "copied";
        setTimeout(function () { btn.textContent = original; }, 1500);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done).catch(done);
      } else {
        done();
      }
    });
  });

  /* ---------------- Terminal typing effect ---------------- */
  var terminalBody = document.querySelector(".terminal-body");
  var terminalLines = [
    "$ whoami",
    "sivasankar-r",
    "full-stack developer",
    "",
    "$ cat skills.txt",
    "java, python, php, c#, javascript, sql, firebase",
    "",
    "$ ls projects/",
    "blogging-platform  e-commerce-app  weather-app  chat-app"
  ];

  function renderTerminalInstant() {
    terminalBody.textContent = terminalLines.join("\n");
  }

  function typeTerminal() {
    var lineIndex = 0;
    var charIndex = 0;
    var output = "";
    terminalBody.textContent = "";
    var caret = document.createElement("span");
    caret.className = "caret";

    function step() {
      if (lineIndex >= terminalLines.length) {
        terminalBody.appendChild(caret);
        return;
      }
      var currentLine = terminalLines[lineIndex];
      if (charIndex <= currentLine.length) {
        terminalBody.textContent = output + currentLine.slice(0, charIndex);
        terminalBody.appendChild(caret);
        charIndex++;
        setTimeout(step, currentLine.length === 0 ? 40 : 18);
      } else {
        output += currentLine + "\n";
        lineIndex++;
        charIndex = 0;
        setTimeout(step, 220);
      }
    }
    step();
  }

  if (terminalBody) {
    if (prefersReducedMotion) {
      renderTerminalInstant();
    } else {
      typeTerminal();
    }
  }

  /* ---------------- Projects data + modal ---------------- */
  var projects = [
    {
      id: "blogging-platform",
      title: "Database-Driven Blogging Platform",
      stack: "Python, SQL",
      summary: "A database-backed blogging system supporting full CRUD capabilities for blog posts and metadata management.",
      features: [
        "Structured relational database schemas in SQL to store post records, timestamps, and relational details",
        "Backend validation logic in Python for incoming payloads before writing to the database",
        "Secure interfacing between the Python backend and the SQL database engine"
      ]
    },
    {
      id: "ecommerce-app",
      title: "E-Commerce Web Application",
      stack: "HTML, CSS, JavaScript, PHP, Firebase",
      summary: "A full-stack e-commerce platform with user authentication, a product catalog, and shopping cart management.",
      features: [
        "Real-time authentication using Firebase Authentication for registration and session handling",
        "Dynamic frontend built in JavaScript, handling cart state and item total calculations",
        "PHP backend interactions to persist product data and user transactions"
      ]
    },
    {
      id: "weather-app",
      title: "REST API Weather Application",
      stack: "C#, .NET, JSON",
      summary: "A weather application retrieving real-time meteorological metrics for locations worldwide via a third-party REST API.",
      features: [
        "Parsed structured JSON API responses to display temperature, humidity, and conditions",
        "Exception and error handling for invalid input or failed network calls",
        "Built on .NET with C#"
      ]
    },
    {
      id: "chat-app",
      title: "Multi-Threaded Chat Application",
      stack: "Java, Socket Programming",
      summary: "A network chat application using Java TCP sockets for real-time messaging between clients.",
      features: [
        "TCP socket programming to enable concurrent client connections",
        "Object-oriented design isolating client/server connection logic",
        "Message buffer management for real-time exchange"
      ]
    }
  ];

  var modalOverlay = document.querySelector(".modal-overlay");
  var modalContent = document.querySelector(".modal");
  var lastFocused = null;

  function openModal(project) {
    lastFocused = document.activeElement;
    modalContent.innerHTML =
      '<button class="modal-close" data-close aria-label="Close project details">&times;</button>' +
      "<h3>" + project.title + "</h3>" +
      '<div class="stack">' + project.stack + "</div>" +
      "<p>" + project.summary + "</p>" +
      "<h4>key features</h4>" +
      "<ul>" + project.features.map(function (f) { return "<li>" + f + "</li>"; }).join("") + "</ul>";
    modalOverlay.classList.add("open");
    modalOverlay.setAttribute("aria-hidden", "false");
    var closeBtn = modalContent.querySelector("[data-close]");
    if (closeBtn) closeBtn.focus();
  }

  function closeModal() {
    modalOverlay.classList.remove("open");
    modalOverlay.setAttribute("aria-hidden", "true");
    if (lastFocused) lastFocused.focus();
  }

  document.querySelectorAll("[data-project]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var project = projects.filter(function (p) { return p.id === btn.getAttribute("data-project"); })[0];
      if (project) openModal(project);
    });
  });

  if (modalOverlay) {
    modalOverlay.addEventListener("click", function (e) {
      if (e.target === modalOverlay || e.target.hasAttribute("data-close")) closeModal();
    });
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && modalOverlay.classList.contains("open")) closeModal();
  });

  /* ---------------- Contact form (mailto, static-site friendly) ---------------- */
  var contactForm = document.querySelector("#contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var name = contactForm.querySelector("#cf-name").value.trim();
      var email = contactForm.querySelector("#cf-email").value.trim();
      var subject = contactForm.querySelector("#cf-subject").value.trim() || "Portfolio contact";
      var message = contactForm.querySelector("#cf-message").value.trim();

      var body = "From: " + name + " (" + email + ")%0D%0A%0D%0A" + encodeURIComponent(message);
      var mailto = "mailto:sivasankar7530@gmail.com?subject=" + encodeURIComponent(subject) + "&body=" + body;
      window.location.href = mailto;
    });
  }
})();
